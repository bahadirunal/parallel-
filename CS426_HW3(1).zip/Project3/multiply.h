#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <string.h>
#include <unistd.h>

#ifndef _multiply_h
#define _multiply_h

int multiply(int *row_ptr, int *col_ind, float *values, float *x, int n, int num_threads, int number_of_repetitions, int input) {
    		
	float temp;

	double start;
	
	double time[number_of_repetitions];

	int i, f, g;
	
	float y[n];
	
	omp_set_num_threads(num_threads);
	

	for (i = 0; i < number_of_repetitions; ++i) {

		if (input == 1) {

			printf("The initial vector before repetition %d\n", i+1);

    			for (int a = 0; a < n; ++a) {

    				printf("%f \n", x[a]);
    			}
		}
				
		start = omp_get_wtime();
		
		#pragma omp parallel for default(shared) private(g, temp)	
				
		for (f = 0; f < n; f++) {
			
			temp = 0.0;
			
		
			for (g = row_ptr[f]; g < row_ptr[f+1]; g++) {
				
				#pragma omp atomic				
				temp += (float)(values[g]*x[col_ind[g]]);
			}

			y[f] = temp; 
		}
				
		#pragma omp barrier

		for(int i = 0; i < n; i++) {

			x[i] = y[i];
		}

		time[i] = omp_get_wtime() - start;

		if (input == 1) {

			printf("The resulting vector after repetition %i\n", i+1);

    			for (int b = 0; b < n; ++b) {

    				printf("%f \n", x[b]);
    			}
    		}

	}

	double total_time = 0.0;
	
	for (int i = 0; i < number_of_repetitions; i++) {
		
		total_time += time[i];
	}


	printf("Time: %1.10f\n", total_time);

	free(row_ptr);
	free(col_ind);
	free(values);
	free(x);
	

}

#endif
