#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <string.h>
#include <unistd.h>
#include "multiply.h"

int main(int argc, char* argv[]) {

	int num_threads = atoi(argv[1]);
	int number_of_repetitions = atoi(argv[2]);
	int input = atoi(argv[3]);
	char *file_name = argv[4];
	
	

	int *row_ptr;
	int *col_ind;
	float *values;
	float *x;
	int n; 

  	int nnz; //number of nonzero elements
  	int nrows;
  	int ncols;

	FILE *file_ptr = fopen(file_name, "r");

 	if (file_ptr == NULL) {
    
    	printf("There is no such file\n");
	}

	
	

	fscanf(file_ptr, "%i %i %i", &nrows, &ncols, &nnz);
	n = nrows;
	row_ptr = malloc(sizeof(int)*n);
	col_ind = malloc(sizeof(int)*nnz);
	values = malloc(sizeof(float)*nnz);
	x = malloc(sizeof(int)*n);
	
	
	
			
	for (int i = 0; i < n; i++) {
        
        row_ptr[i] = 0;
        x[i] = 1.0;
    	}
	
	
	
	
 
    
    for (int i = 0; i < nnz; i++) {
        
        values[i] = 0.0;
        col_ind[i] = 0;
    }

    int number_of_lines = 0;
    char ch;

    do 
	{
    	ch = fgetc(file_ptr);
    	
    	if (ch == '\n') {

    		number_of_lines++;
		}
        
	} while (ch != EOF);

	if (ch != '\n' && number_of_lines != 0) {
    	
    	number_of_lines++;
	}
	
	number_of_lines = number_of_lines-2;
	
	rewind(file_ptr);

	int *I = (int *) malloc(sizeof(int)*number_of_lines);
	int *J = (int *) malloc(sizeof(int)*number_of_lines);
	float *V = (float *) malloc(sizeof(float)*number_of_lines);
	int a;
	int b;
	float c;
	fscanf(file_ptr, "%d %d %f\n", &a, &b, &c);

	

	for (int i = 0; i < number_of_lines; i++) {
 
        fscanf(file_ptr, "%d %d %f\n", &I[i], &J[i], &V[i]);
        I[i]--;
        J[i]--;
	
    }



    if (input == 1) {

    	printf("The initial matrix: \n");

    	for (int i = 0; i < number_of_lines; i++) {
	
    		printf("%i %i %f \n", I[i], J[i], V[i]);
    	}
    }


    fclose(file_ptr);

    float **matrix = (float**) malloc(number_of_lines*sizeof(float*));
            
    for (int i = 0; i < number_of_lines; i++) {
        
        matrix[i] = (float*) malloc(number_of_lines*sizeof(float));
    }

                    
    for (int j = 0; j < n; j++) {
        
        for(int k = 0; k < n; k++) {
            
            matrix[j][k] = 0.0;
        }
    }


    
    for (int i = 0; i < number_of_lines; i++) {
        
    	int j = I[i];
        int k = J[i];
        matrix[j][k] = V[i];
    }
/*

	  for (int j = 0; j <n; j++) {

        

        for(int k = 0; k < n; k++) {

            printf("%f\n", matrix[j][k]);
        }
    }
*/
	
	
	



    int index = 0;
    int j, k;

    for (j = 0; j < n; j++) {

    	for (k = 0; k < n; k++) {

    		if (matrix[j][k] != 0) {

    			values[index] = matrix[j][k];
                	col_ind[index] = k;
                	index++;
            }
        }
	if(j+1 <= n) {

       	row_ptr[j+1] = index;
	}
    }
	

	
	multiply(row_ptr, col_ind, values, x, n, num_threads, number_of_repetitions, input);

	return 0;
}

