#!/bin/bash

make
 
./multiply.out "$1" "$2" "$3" "$4" 
